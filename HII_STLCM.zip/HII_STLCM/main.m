%% ===============================================
%  HII-STLCM
%  Description:Infrared Small Target Detection Based on Holistic Interframe Interaction and Spatiotemporal Local Contrast Method
% =================================================

clear; clc;
addpath("func\")
%% ------------------ Path Settings ------------------
img_path = '.\data21';
frame_diff_path = '.\data21_res_frame_diff';
output_path     = '.\data21_res';

% Create output folders if not exist
if ~exist(output_path, 'dir')
    mkdir(output_path);
end
if ~exist(frame_diff_path, 'dir')
    mkdir(frame_diff_path);
end

%% ------------------ Load Image List ------------------
img_path_list = dir(fullfile(img_path, '*.bmp')); % Get all bmp images
num = length(img_path_list);
files_name = sort_nat({img_path_list.name});      % Natural order sort

% Pre-read images (convert to gray if needed)
for i = 1:num
    newname = fullfile(img_path, files_name{i});
    img1 = imread(newname);
    if ndims(img1) == 3
        img1 = rgb2gray(img1);
    end
end

%% ------------------ Main Processing Loop ------------------
t_thr = 5; % temporal interval

for i = 1:num
    tic;
    if i > t_thr && (i + t_thr) <= num
        % ----- Load reference frames -----
        I_prev = rgb2gray(imread(fullfile(img_path, files_name{i-t_thr})));
        I_mid  = rgb2gray(imread(fullfile(img_path, files_name{i})));
        I_next = rgb2gray(imread(fullfile(img_path, files_name{i+t_thr})));
        
        % ----- Registration -----
        [regis_prev, x1, y1] = registration_1(I_mid(:,:,1), I_prev(:,:,1));
        [regis_next, x2, y2] = registration_1(I_mid(:,:,1), I_next(:,:,1));
        
        % ----- Compute max translation -----
        x_max = ceil(max(x1, x2));
        y_max = ceil(max(y1, y2));
        
        % ----- Frame differences -----
        D1 = double(I_mid) - double(regis_prev);
        D2 = double(regis_next) - double(I_mid);
        
        % Zero-out unreliable borders
        D1 = mask_border(D1, x_max, y_max);
        D2 = mask_border(D2, x_max, y_max);
        
        % ----- Temporal difference result -----
        frame_diff = mat2gray(max(D1, D2));
        
        % Save intermediate frame difference
        imwrite(frame_diff, fullfile(frame_diff_path, files_name{i}));
        
        % ----- Morphology & Contrast Analysis -----
        histogram_res = candidate_mask_learnbykou(frame_diff);
        [SCR_map, TEMPORAL_map] = Morphology_analysis(files_name{i}, ...
                                                      histogram_res, ...
                                                      img_path, ...
                                                      t_thr, frame_diff);
        result = SCR_map .* TEMPORAL_map;
        
    else
        % ----- For first t_thr frames -----
        pic2 = imread(fullfile(img_path, files_name{i}));
        pic2 = pic2(:,:,1);
        result = dgradfunc(pic2);
    end
    
    % ----- Apply threshold -----
    result = threshold_top_percent(result, 0.001);
    
    % Save final result
    imwrite(mat2gray(result), fullfile(output_path, files_name{i}));
    frameTime = toc;  % 结束计时
    fprintf('Frame %d/%d processed in %.3f seconds.\n', i, num, frameTime);
end


function I_masked = mask_border(I, x_max, y_max)
    % Mask unreliable border regions based on translation
    I(:, 1:x_max+1)        = 0;
    I(:, end-x_max:end)    = 0;
    I(1:y_max+1, :)        = 0;
    I(end-y_max:end, :)    = 0;
    I_masked = I;
end

function I_thresh = threshold_top_percent(I, percent)
    % Keep only top percent pixels
    I = double(I);
    sorted_vals = sort(I(:), 'descend');
    idx = round(percent * numel(sorted_vals));
    T = sorted_vals(idx);
    mask = I >= T;
    I_thresh = I .* mask;
end



