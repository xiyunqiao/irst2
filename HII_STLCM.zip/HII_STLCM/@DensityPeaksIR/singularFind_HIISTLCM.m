function [ classInitial, classInitial_tmp] = singularFind_HIISTLCM( obj, rho, delta)
%SINGULARFIND Find the density peaks in rho-delta space.
% rho--density of each pixel, a vector with the size of [m*n, 1].
% delta--delta-space of each pixel, a vector with the size of [m*n, 1].
% classInitial--the sign vector with the size of [m*n, 1], the positions 
% with non-zero values represent density peaks.

nLength = length(rho);
classInitial = zeros(nLength, 1);
classInitial_tmp = zeros(nLength, 1);

%% find the singular points with product
normalized_delta = (delta - min(delta)) / (max(delta) - min(delta));
normalized_rho = (rho - min(rho)) / (max(rho) - min(rho));

product = normalized_rho.*normalized_rho.*normalized_delta;
[productSort, index] = sort(product, 'descend');
cl = 1;
c2 = 1;
% threashold = max(product) / obj.rhoDeltaThd;  % set the threashold
threashold = productSort(obj.numSeeds);
threashold2 = productSort(floor(obj.numSeeds*0.3));
for i = 1 : nLength
    if ( product(index(i)) >= threashold )
        classInitial( index(i) ) = cl;
        cl = cl+1;
    end
    if ( product(index(i)) >= threashold2 )
        classInitial_tmp( index(i) ) = c2;
        c2 = c2+1;
    end
end

end

