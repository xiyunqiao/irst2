function [registered_img, translation_x, translation_y] = registration_1(I_ref, I_moving)
    % Perform rigid registration (translation + rotation), then ignore rotation.
    optimizer = registration.optimizer.RegularStepGradientDescent;
    optimizer.MinimumStepLength = 1e-6;
    optimizer.MaximumIterations = 30;
    metric = registration.metric.MeanSquares;
    
    % Estimate transform
    tform = imregtform(I_moving, I_ref, 'rigid', optimizer, metric);
    A = tform.T;        % Get transformation matrix
    tform.T = A;        % Keep translation
    
    % Apply registration
    output_view = imref2d(size(I_ref));
    registered_img = imwarp(I_moving, tform, 'OutputView', output_view);
    
    translation_x = A(3,1);
    translation_y = A(3,2);
end



