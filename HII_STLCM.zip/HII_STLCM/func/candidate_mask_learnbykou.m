function [labeled_img] = candidate_mask_learnbykou(img)
[row, col] = size(img);
k_Th = 1;%阈值参数
detWay = DensityPeaksIR();
rhoMat = img;
m = size(rhoMat, 1);
[rho, delta] = iterationElection( detWay, rhoMat );
% scatter(rho, delta, 'filled'); % 'filled' 是填充标记
% xlabel('rho', 'FontName', 'Times New Roman', 'FontSize', 16, 'FontWeight', 'bold', 'FontAngle', 'italic');  % 设置字体、大小、粗体、斜体
% ylabel('delta', 'FontName', 'Times New Roman', 'FontSize', 16, 'FontWeight', 'bold', 'FontAngle', 'italic');  % 设置字体、大小、粗体、斜体
% 
% 
% set(gca, 'FontName', 'Arial', 'FontSize', 16, 'FontWeight', 'normal');  % 轴刻度字体
% 
% grid on
[classInitial, classInitial_high] = singularFind_HIISTLCM( detWay, rho, delta );

singularIndex = find( classInitial ~=  0 );
classCenterRows = mod( singularIndex, m );
classCenterRows(classCenterRows == 0) = m;
classCenterCols = ceil( singularIndex / m );

singularIndex_high = find( classInitial_high ~=  0 );
classCenterRows_high = mod( singularIndex_high, m );
classCenterRows_high(classCenterRows_high == 0) = m;
classCenterCols_high = ceil( singularIndex_high / m );
img_norm = zeros(row, col);

for I = 1:size(classCenterRows)
    img_norm(classCenterRows(I), classCenterCols(I)) = 1;
    
end

for I = 1:size(classCenterRows_high)
    img_norm(classCenterRows_high(I), classCenterCols_high(I)) = 2;   
end

labeled_img = img_norm;

