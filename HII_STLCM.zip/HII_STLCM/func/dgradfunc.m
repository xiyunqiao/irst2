%% ==================== Helper Function ====================
function re = dgradfunc(img)
% Compute local saliency contrast
[row, col] = size(img);
len = 3;
nr = 5;
nc = 5;
leny = len * nr;
lenx = len * nc;
op = zeros(leny, lenx, nr * nc);

% Generate multi-scale Gaussian filters
for ii = 1:nr*nc
    temp = zeros(leny, lenx);
    [r, c] = ind2sub([nr, nc], ii);
    if ii == 13
        sigma = 0.1772;
        gaussianFilter = fspecial('gaussian', [len, len], sigma);
        temp((r-1)*len+1:r*len, (c-1)*len+1:c*len) = gaussianFilter;
    else
        temp((r-1)*len+1:r*len, (c-1)*len+1:c*len) = 1;
    end
    temp = temp / sum(temp(:));
    op(:,:,ii) = temp';
end

gimg = zeros(row, col, nr*nc);
for ii = 1:nr*nc
    gimg(:,:,ii) = imfilter(img, op(:,:,ii), 'replicate');
end

% Compute inner and outer contrast
m2 = gimg;
m2(:,:, [1:6,10:11,13,15:16,20:25]) = [];
t2 = repmat(gimg(:,:,13),1,1,8) - m2;
t2(t2 <= 0) = 0;
d2 = min(t2, [], 3);

m1 = gimg;
m1(:,:, [7:9,12:14,17:19]) = [];
t1 = abs(repmat(gimg(:,:,13),1,1,16) - m1);
d1 = mean(t1, 3);
d1 = d1 ./ (gimg(:,:,13) + 0.1);

re = d1 .* d2;
end
