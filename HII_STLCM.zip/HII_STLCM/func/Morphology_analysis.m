function [SCR_map, TEMPORAL_map] = Morphology_analysis(filename, S_map_B, img_path, t_thr, frame_d)
%TEMPORAL_ANALYSIS Generate SCR and Temporal maps for small infrared targets
%   filename : current frame filename
%   S_map_B  : binary candidate mask from histogram
%   img_path : path to image sequence
%   t_thr    : temporal radius
%   frame_d  : current frame difference map

% Load temporal sequence centered at current frame
filename_org = filename;
len = length(filename_org) - 4;
index_filename = str2double(filename_org(1:len));

D = zeros(256, 256, 2 * t_thr + 1);
for t = 1:(2 * t_thr + 1)
    tmp_index = t + index_filename - t_thr - 1;
    tmp = imread(fullfile(img_path, sprintf('%d.bmp', tmp_index)));
    D(:,:,t) = tmp(:,:,1);
end

[row, col] = size(S_map_B);
Conn_struct = bwconncomp(S_map_B);

SCR_map = zeros(row, col);
TEMPORAL_map = zeros(row, col);

scale_factor = 5;
win_size = scale_factor * 3;
r_win = (win_size - 1) / 2;
r_win_temporal = 2;

for i = 1:Conn_struct.NumObjects
    % Pixel indices of current connected component
    Conn_index = Conn_struct.PixelIdxList{i};
    Conn_num = length(Conn_index);
    
    % Convert linear indices to subscripts
    Conn_position = zeros(Conn_num, 2);
    for j = 1:Conn_num
        Conn_position(j,1) = mod(Conn_index(j)-1, row) + 1;
        Conn_position(j,2) = floor((Conn_index(j)-1)/row) + 1;
    end
    
    % ----- SCR Map -----
    for j = 1:Conn_num
        r = Conn_position(j,1);
        c = Conn_position(j,2);
        if (r - r_win > 0) && (r + r_win <= row) && (c - r_win > 0) && (c + r_win <= col)
            patch_SCR = frame_d(r - r_win : r + r_win, c - r_win : c + r_win);
            result = dgradfunc(patch_SCR);
            SCR_map(r, c) = max(result(:));
        end
    end
    
    % ----- Temporal Map -----
    channels = size(D, 3);
    list_max = zeros(channels, 1);
    for j = 1:Conn_num
        r = Conn_position(j,1);
        c = Conn_position(j,2);
        if (r - r_win > 0) && (r + r_win <= row) && (c - r_win > 0) && (c + r_win <= col)
            for t = 1:channels
                patch_TEMPORAL = D(r-r_win_temporal:r+r_win_temporal, c-r_win_temporal:c+r_win_temporal, t);
                list_max(t) = mean(patch_TEMPORAL(:));
            end
            TEMPORAL_map(r, c) = (max(list_max) - min(list_max))^2 * S_map_B(r, c);
        end
    end
end

end


